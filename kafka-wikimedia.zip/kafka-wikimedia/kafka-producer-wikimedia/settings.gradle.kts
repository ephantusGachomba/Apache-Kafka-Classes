rootProject.name = "kafka-producer-wikimedia"

