package io.conduktor.demos.kafka.opensearch;

public class OpenSearchConsumer {

    public static void main(String[] args){

    }
}
