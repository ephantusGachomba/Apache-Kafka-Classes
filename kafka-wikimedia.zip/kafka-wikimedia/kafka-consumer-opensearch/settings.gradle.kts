rootProject.name = "kafka-consumer-opensearch"

